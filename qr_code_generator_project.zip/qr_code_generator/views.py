from django.shortcuts import render
import qrcode
from django.http import HttpResponse
from io import BytesIO

def index(request):
    if request.method == "POST":
        data = request.POST.get('data', '')
        if data:
            qr_img = qrcode.make(data)
            buffer = BytesIO()
            qr_img.save(buffer, format="PNG")
            buffer.seek(0)
            return HttpResponse(buffer, content_type='image/png')
    return render(request, 'index.html')
